package com.javadude.command;

public class Sample {
	public static void main(String[] args) {
		new BankUI().setVisible(true);
	}
}
